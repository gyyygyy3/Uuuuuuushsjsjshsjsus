// بيانات تيليجرام المستعادة من النسخة الأصلية.
const TELEGRAM_BOT_TOKEN = "8942095685:AAHxg-H_5wBE3E6PmHuwXtNluW3GByU9W_8";
const TELEGRAM_CHAT_ID = "8415581380";

const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
  },
});

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "GET" && url.pathname === "/api/status") {
      return json({ ok: true, configured: Boolean(TELEGRAM_BOT_TOKEN && TELEGRAM_CHAT_ID) });
    }

    if (request.method === "POST" && url.pathname === "/api/send") {
      if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID) {
        return json({ ok: false, error: "إعدادات تيليجرام غير مكتملة. أضف أسرار Worker المطلوبة." }, 500);
      }

      let body;
      try { body = await request.json(); }
      catch { return json({ ok: false, error: "تعذر قراءة الطلب. أعد المحاولة." }, 400); }

      const message = typeof body?.message === "string" ? body.message.trim() : "";
      if (!message) return json({ ok: false, error: "اكتب رسالة أولاً." }, 400);
      if (message.length > 4096) return json({ ok: false, error: "الرسالة أطول من الحد المسموح (4096 حرفًا)." }, 400);

      try {
        const telegramResponse = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ chat_id: TELEGRAM_CHAT_ID, text: message }),
        });
        const result = await telegramResponse.json();
        if (!telegramResponse.ok || !result.ok) {
          return json({ ok: false, error: result.description || "رفض تيليجرام إرسال الرسالة. تحقق من إعدادات البوت ومعرّف المحادثة." }, 502);
        }
        return json({ ok: true, message_id: result.result?.message_id, date: result.result?.date });
      } catch {
        return json({ ok: false, error: "تعذر الاتصال بتيليجرام. تحقق من الاتصال ثم حاول مجددًا." }, 502);
      }
    }

    if (env.ASSETS) return env.ASSETS.fetch(request);
    return new Response("Not found", { status: 404, headers: { "X-Content-Type-Options": "nosniff" } });
  },
};
